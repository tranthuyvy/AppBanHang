<?php
include "connect.php";
$trangthai = $_POST['trangthai'];

$query = "SELECT * FROM `donhang` WHERE `trangthai` = '".$trangthai."'";
$data = mysqli_query($conn, $query);
$result = array();
// echo $query;
while ($row = mysqli_fetch_assoc($data)) {
    $result[] = ($row);
    // code...
}
if (!empty($result)){
    $arr = [
        'success' => true,
        'message' => "thanh cong",
        'result' => $result
    ];
}else{
    $arr = [
        'success' => false,
        'message' => "khong thanh cong",
        'result' => $result
    ];
}

print_r(json_encode($arr));

?>