<?php
$host="localhost";
$username="root";
$password="";
$database="datalezada";

$conn = mysqli_connect($host,$username,$password,$database);

 mysqli_query($conn,"SET NAME '.utf8.'");

	// if($conn)
	// {
	// 	echo"Thành công";
	// }
	// else
	// {
	// 	echo"Kết nối thất bại";
	// }
?>
