<?php
include "connect.php";
$email = $_POST['email'];
$pass = $_POST['pass'];
$username = $_POST['username'];
$mobile = $_POST['mobile'];
$uid = $_POST['uid'];

//check email
$query = 'SELECT * FROM `user` WHERE `email` = "'.$email.'"';
$data = mysqli_query($conn, $query);
$numrow = mysqli_num_rows($data);	//hàm ktra xem có dữ liệu trả về hay không?
//echo $numrow; //Xem số lượng email trùng

if ($numrow > 0) {
	$arr = [
		'success' => false,
		'message' => "Email da ton tai",
		
	];
	
}else{

	//insert
	$query = 'INSERT INTO `user`(`email`, `pass`, `user_name`, `mobile`, `uid`) VALUES ("'.$email.'","'.$pass.'","'.$username.'","'.$mobile.'","'.$uid.'")';
	$data = mysqli_query($conn, $query);

	if ($data == true){
		$arr = [
			'success' => true,
			'message' => "thanh cong",
			
		];
	}else{
		$arr = [
			'success' => flase,
			'message' => "khong thanh cong",
			
		];
	}
}

print_r(json_encode($arr));

?>